
For basic example of declaring friend function, refer to slide 15

##################################################

To observe the implementation difference between : 
1) 'friend' functions
2) class's 'member' functions

Refer to slide 17

##################################################

For basic example of operator overloading (for '+'), refer to slide 42-45

##################################################

For basic example of operator overloading (for '<<' and '>>'), refer to slide 50-55

##################################################

With the provided notes and APIs and example codes as the starting point, 

(1) Search online for even more examples as references
(2) Adapt and use if to provide accurate formatting for your Assignment!!!


