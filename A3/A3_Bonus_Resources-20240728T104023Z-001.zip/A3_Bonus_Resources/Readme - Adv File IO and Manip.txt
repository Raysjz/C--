
For example on : 
- setting the width (i.e. cout.width())
- "left"/"right" justify (i.e. cout.setf(...))

Refer to code snippets in slide 23!!!

##################################################

For BASIC example on writing your own output manipulator, and how to invoke

Refer to program in slide 47 !!!

##################################################

For ADVANCED example on writing your own output manipulator, and how to invoke

Refer to program in slide 48-49 !!!

(also includes example on setting precision for floating point numbers !!!)

##################################################

With the provided APIs and example codes as the starting point, 

(1) Search online for even more examples as references
(2) Adapt and use if to provide accurate formatting for your Assignment 3 !!!


